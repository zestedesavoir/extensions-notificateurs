# Ce qui a été fait pour le moment.  
+ Lorsque l'utilisateur est déconnecté, Clem devient rouge et on a un lien vers la page de connexion.  
+ Lorsqu'il n'y a pas de notifications, Clem est normale et on peut voir le message Aucune notifications.  
+ Dès qu'il y a une notification, le logo change et on peut directement cliquer sur la notification qui s'ouvre dans un nouvel onglet.
+ La page à propos.
# Ce qui reste à faire pour la V1.  
+ Affichage des MP. EDIT : FAIT.
+ Enlever la fleche à droite de Clem. EDIT : FAIT
+ Grossir Clem. EDIT : FAIT
+ Aligner à gauche les notifications. EDIT : FAIT
+ Ajouter le nombre de notifs/MP dans une bulle. Améliorer le CSS des bouttons notifs+MP (En cours)
+ N'étant pas développeur Web, le code peut en faire pleurer plus d'un... Il faut que je reprenne le code pour qu'il ressemble un peu plus à la version Chrome (dans la limite du possible).  
+ Éviter de réaliser plusieurs update au même moment (Bug non génant, mais je préfère le faire).  
+ Fermer l'extension à l'ouverture d'une notifications ? Je ne suis pas sur, c'est embettant quand on a plusieurs notifications.  
+ Peut être mettre moins à jour ? Dans le cas présent, les notifications se mettent à jour à chaque clic dans Firefox (+ toutes les 60 secondes)...  
# Idées
+ Ajouter un bouton ouvrir toutes les notifications.  
+ Un systeme de message en bas à droite à chaque notifications/MP.  
+ Si le topic de la notification est déjà ouverte, rafraichir l'onglet au lieu d'en ouvrir un nouveau.  
+ Update automatique (facile à mettre en place pour Firefox)  
+ Ajouter un badge à droite type (nombre MP - nombre notifs)
# Testez  
Pour le moment, l'extension n'est pas disponible sur le marketplace (car pas en V1). Pour tester l'extension, je vous demande de télécharger le fichier .xpi [ici](http://enconn.fr/zds-notif.xpi). Puis de glisser déposer le fichier sur cette page : about:addons.  
